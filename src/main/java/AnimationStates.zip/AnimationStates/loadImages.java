package AnimationStates;

import javafx.scene.image.Image;

import java.io.InputStream;
import java.util.ArrayList;

public class loadImages {

    private static final double SCALE = 0.25;

    public static Image[] loadSequence(String folderPath) {

        ArrayList<Image> frames = new ArrayList<>();
        int index = 1;

        String prefix = folderPath.substring(folderPath.lastIndexOf('/') + 1);

        while (true) {
            String fileName = String.format("%s/%s%04d.png", folderPath, prefix, index);

            InputStream stream = loadImages.class.getResourceAsStream(fileName);

            if (stream == null) {
                // If we haven't loaded anything yet, this is a real error
                if (index == 1) {
                    System.out.println("Missing first frame: " + fileName);
                    break;
                }

                // If we HAVE loaded frames, missing means "end of sequence"
                // BUT we do NOT break early — we check if more frames exist
                index++;
                continue;
            }

            // Load and scale
            Image original = new Image(stream);
            double targetWidth = original.getWidth() * SCALE;
            double targetHeight = original.getHeight() * SCALE;

            InputStream stream2 = loadImages.class.getResourceAsStream(fileName);
            Image scaled = new Image(stream2, targetWidth, targetHeight, true, true);

            frames.add(scaled);
            index++;
        }

        System.out.println("Loaded " + frames.size() + " frames from " + folderPath);
        return frames.toArray(new Image[0]);
    }



}
